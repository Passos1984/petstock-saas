from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from collections import Counter
import csv  
import io   

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///petstock.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'chave_mestre_guilherme_petstock' 

db = SQLAlchemy(app)

def hora_brasilia():
    return datetime.utcnow() - timedelta(hours=3)

@app.context_processor
def injetar_dados_globais():
    loja_atual = None
    if 'loja_id' in session:
        loja_atual = Loja.query.get(session['loja_id'])
    return dict(loja_logada=loja_atual, cargo=session.get('cargo', 'Caixa'), vendedor_atual=session.get('vendedor', ''))

# ==========================================
# TRAVA DE ASSINATURA (SaaS)
# ==========================================
@app.before_request
def verificar_mensalidade():
    rotas_livres = ['login', 'logout', 'admin_guilherme', 'editar_loja', 'static', 'resetar_senha_loja']
    if request.endpoint in rotas_livres or not request.endpoint:
        return
        
    if 'loja_id' in session:
        loja = Loja.query.get(session['loja_id'])
        if loja:
            hoje = hora_brasilia().date()
            dias_restantes = (loja.data_vencimento - hoje).days
            
            link_wpp = '<a href="https://api.whatsapp.com/send?phone=5551981962819" target="_blank" style="color: inherit; text-decoration: underline; font-weight: 800;">Chame o Suporte clicando AQUI</a>'
            
            if dias_restantes < 0:
                session.clear()
                flash(f'🚨 ACESSO BLOQUEADO: Sua mensalidade venceu! {link_wpp} para liberar o sistema.', 'danger')
                return redirect(url_for('login'))
                
            if 0 <= dias_restantes <= 3:
                rotas_de_tela = ['home', 'pdv', 'clientes', 'representantes', 'radar', 'relatorios', 'funcionarios']
                if request.endpoint in rotas_de_tela:
                    flashes = session.get('_flashes', [])
                    ja_tem_aviso = any('Suporte' in m[1] for m in flashes)
                    if not ja_tem_aviso:
                        if dias_restantes == 0:
                            flash(f'🚨 URGENTE: Sua assinatura vence HOJE! {link_wpp} para não perder o acesso amanhã.', 'danger')
                        else:
                            flash(f'⚠️ ATENÇÃO: Sua assinatura vence em {dias_restantes} dia(s). {link_wpp} para renovar e evitar bloqueio!', 'warning')

# ==========================================
# MODELOS DE BANCO DE DADOS
# ==========================================
class Loja(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome_fantasia = db.Column(db.String(100), nullable=False)
    usuario = db.Column(db.String(100), unique=True, nullable=False)
    senha = db.Column(db.String(255), nullable=False)
    data_vencimento = db.Column(db.Date, nullable=False)
    primeiro_acesso = db.Column(db.Boolean, default=True)

class Funcionario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    usuario = db.Column(db.String(50), unique=True, nullable=False)
    senha = db.Column(db.String(255), nullable=False)
    cargo = db.Column(db.String(20), default='Caixa')
    primeiro_acesso = db.Column(db.Boolean, default=True)
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)

class Representante(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome_fantasia = db.Column(db.String(100), nullable=False)
    cnpj = db.Column(db.String(20))
    representante_nome = db.Column(db.String(100))
    whatsapp = db.Column(db.String(20))
    prazo_entrega = db.Column(db.String(50))
    pedido_minimo = db.Column(db.String(50))
    observacoes = db.Column(db.String(200))
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)

class Produto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    codigo_sku = db.Column(db.String(50), nullable=False)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.String(200))
    categoria = db.Column(db.String(50))
    preco_venda = db.Column(db.Float, nullable=False)
    preco_custo = db.Column(db.Float, default=0.0) 
    estoque = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)
    
class Cliente(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    telefone = db.Column(db.String(20), nullable=False)
    cpf = db.Column(db.String(20))
    nome_pet = db.Column(db.String(100))
    nome_pet_2 = db.Column(db.String(100))
    nome_pet_3 = db.Column(db.String(100))
    rua = db.Column(db.String(150))
    numero = db.Column(db.String(20))
    apartamento = db.Column(db.String(50))
    bairro = db.Column(db.String(100))
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)

class Venda(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    produto_id = db.Column(db.Integer, db.ForeignKey('produto.id'), nullable=False)
    cliente_id = db.Column(db.Integer, db.ForeignKey('cliente.id'), nullable=True)
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)
    quantidade = db.Column(db.Float, nullable=False)
    forma_pagamento_1 = db.Column(db.String(50), nullable=False)
    valor_pago_1 = db.Column(db.Float, nullable=False)
    forma_pagamento_2 = db.Column(db.String(50))
    valor_pago_2 = db.Column(db.Float, default=0.0)
    data_venda = db.Column(db.DateTime, default=hora_brasilia)
    data_previsao_fim = db.Column(db.DateTime, nullable=False)
    vendedor = db.Column(db.String(100))
    produto = db.relationship('Produto', backref='vendas_realizadas')
    comprador = db.relationship('Cliente', backref='compras_realizadas')

class VendaPerdida(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome_produto = db.Column(db.String(150), nullable=False)
    data_registro = db.Column(db.DateTime, default=hora_brasilia)
    loja_id = db.Column(db.Integer, db.ForeignKey('loja.id'), nullable=False)

# ==========================================
# ROTAS DE ADMINISTRAÇÃO (CEO) E LOGIN
# ==========================================
@app.route('/admin_guilherme', methods=['GET', 'POST'])
def admin_guilherme():
    if request.method == 'POST':
        nome = request.form.get('nome_fantasia')
        usuario = request.form.get('usuario').strip().lower()
        venc = datetime.strptime(request.form.get('data_vencimento'), '%Y-%m-%d').date()
        
        loja_existente = Loja.query.filter_by(usuario=usuario).first()
        if loja_existente:
            flash(f'⚠️ Erro: O usuário "{usuario}" já está em uso por outra loja!', 'danger')
            return redirect(url_for('admin_guilherme'))
            
        nova = Loja(nome_fantasia=nome, usuario=usuario, senha=generate_password_hash('123456'), data_vencimento=venc)
        db.session.add(nova); db.session.commit()
        flash('✅ Loja criada com sucesso!', 'success')
        return redirect(url_for('admin_guilherme'))
    lojas = Loja.query.order_by(Loja.id.desc()).all()
    return render_template('admin.html', lojas=lojas)

@app.route('/editar_loja/<int:id>', methods=['GET', 'POST'])
def editar_loja(id):
    loja = Loja.query.get_or_404(id)
    if request.method == 'POST':
        loja.nome_fantasia = request.form.get('nome_fantasia')
        novo_usuario = request.form.get('usuario')
        if novo_usuario:
            loja.usuario = novo_usuario.strip().lower()
        nova_data = request.form.get('data_vencimento')
        if nova_data:
            loja.data_vencimento = datetime.strptime(nova_data, '%Y-%m-%d').date()
        db.session.commit()
        flash('✅ Dados da loja atualizados!', 'success')
        return redirect(url_for('admin_guilherme'))
    return render_template('editar_loja.html', loja=loja)

@app.route('/excluir_loja/<int:id>')
def excluir_loja(id):
    loja = Loja.query.get_or_404(id)
    db.session.delete(loja)
    db.session.commit()
    flash('🗑️ Loja excluída do sistema.', 'warning')
    return redirect(url_for('admin_guilherme'))

@app.route('/resetar_senha_loja/<int:id>')
def resetar_senha_loja(id):
    loja = Loja.query.get_or_404(id)
    loja.senha = generate_password_hash('123456')
    loja.primeiro_acesso = True
    db.session.commit()
    flash(f'🔄 Senha da loja "{loja.nome_fantasia}" resetada para 123456!', 'success')
    return redirect(url_for('admin_guilherme'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = request.form.get('login').strip().lower()
        s = request.form.get('senha').strip()
        
        loja = Loja.query.filter_by(usuario=u).first()
        if loja and check_password_hash(loja.senha, s):
            session.update({'loja_id': loja.id, 'cargo': 'Gerente', 'vendedor': 'Dono/Gerente', 'tipo_acesso': 'loja', 'usuario_id': loja.id})
            if loja.primeiro_acesso: return redirect(url_for('mudar_senha'))
            return redirect(url_for('home'))
            
        func = Funcionario.query.filter_by(usuario=u).first()
        if func and check_password_hash(func.senha, s):
            session.update({'loja_id': func.loja_id, 'cargo': func.cargo, 'vendedor': func.nome, 'tipo_acesso': 'funcionario', 'usuario_id': func.id})
            if getattr(func, 'primeiro_acesso', False):
                return redirect(url_for('mudar_senha'))
            if func.cargo == 'Gerente': return redirect(url_for('home'))
            else: return redirect(url_for('pdv'))
            
        flash('Login inválido!', 'danger')
    return render_template('login.html')

@app.route('/mudar_senha', methods=['GET', 'POST'])
def mudar_senha():
    if 'loja_id' not in session: return redirect(url_for('login'))
    
    tipo_acesso = session.get('tipo_acesso', 'loja')
    usuario_id = session.get('usuario_id', session['loja_id'])
    
    if request.method == 'POST':
        nova = request.form.get('nova_senha')
        confirma = request.form.get('confirma_senha')
        if nova != confirma:
            flash('As senhas não conferem!', 'danger')
            return redirect(url_for('mudar_senha'))
            
        if tipo_acesso == 'loja':
            user = Loja.query.get(usuario_id)
        else:
            user = Funcionario.query.get(usuario_id)
            
        if user:
            user.senha = generate_password_hash(nova)
            user.primeiro_acesso = False
            db.session.commit()
            flash('🔒 Senha alterada com sucesso!', 'success')
            
        if session.get('cargo') == 'Caixa':
            return redirect(url_for('pdv'))
        return redirect(url_for('home'))
        
    return render_template('mudar_senha.html')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

# ==========================================
# GESTÃO DE PRODUTOS E ESTOQUE
# ==========================================
@app.route('/')
def home():
    if 'loja_id' not in session: return redirect(url_for('login'))
    
    # --- CÁLCULOS PARA O PAINEL DE COMANDO ---
    hoje_inicio = hora_brasilia().replace(hour=0, minute=0, second=0, microsecond=0)
    vendas_hoje_query = Venda.query.filter_by(loja_id=session['loja_id']).filter(Venda.data_venda >= hoje_inicio).all()
    
    # 1. Total de Vendas hoje
    v_hoje = sum(v.valor_pago_1 + (v.valor_pago_2 or 0) for v in vendas_hoje_query)
    
    # 2. Lucro hoje (Venda - Custo)
    l_hoje = sum((v.valor_pago_1 + (v.valor_pago_2 or 0)) - ((v.produto.preco_custo or 0) * v.quantidade) for v in vendas_hoje_query)
    
    # 3. Alertas do Radar (Clientes que precisam de ração nos próximos 7 dias)
    prazo_radar = hora_brasilia() + timedelta(days=7)
    alertas_count = Venda.query.filter_by(loja_id=session['loja_id']).filter(Venda.data_previsao_fim <= prazo_radar).count()
    
    # Dados normais da página
    prods = Produto.query.filter_by(loja_id=session['loja_id'], ativo=True).all()
    ult = Produto.query.filter_by(loja_id=session['loja_id']).order_by(Produto.id.desc()).first()
    prox = f"{ult.id + 1:02d}" if ult else "01"
    
    return render_template('index.html', 
                           produtos=prods, 
                           proximo_sku=prox,
                           vendas_hoje=f"{v_hoje:.2f}".replace('.', ','),
                           lucro_hoje=f"{l_hoje:.2f}".replace('.', ','),
                           alertas_radar=alertas_count)

@app.route('/cadastrar_produto', methods=['POST'])
def cadastrar_produto():
    p = Produto(
        codigo_sku=request.form.get('sku'),
        nome=request.form.get('nome'),
        descricao=request.form.get('descricao'),
        categoria=request.form.get('categoria'),
        preco_custo=float(request.form.get('preco_custo').replace(',', '.')),
        preco_venda=float(request.form.get('preco').replace(',', '.')),
        estoque=float(request.form.get('quantidade').replace(',', '.')),
        loja_id=session['loja_id']
    )
    db.session.add(p); db.session.commit()
    flash('📦 Produto Salvo!', 'success')
    return redirect(url_for('home'))

# --- NOVO MOTOR DE IMPORTAÇÃO DE PLANILHAS CSV ---
@app.route('/importar_produtos', methods=['POST'])
def importar_produtos():
    if 'loja_id' not in session: return redirect(url_for('login'))
    loja_id = session['loja_id']
    
    if 'arquivo' not in request.files:
        flash('Nenhum arquivo selecionado.', 'danger')
        return redirect(request.referrer)

    arquivo = request.files['arquivo']
    
    if arquivo and arquivo.filename.endswith('.csv'):
        try:
            stream = io.StringIO(arquivo.stream.read().decode("UTF8"), newline=None)
            leitor = csv.DictReader(stream, delimiter=',') 
            
            produtos_adicionados = 0
            
            for linha in leitor:
                # Aceita tanto 'Nome_Produto' quanto 'NomeProduto'
                nome = linha.get('Nome_Produto') or linha.get('NomeProduto')
                if not nome:
                    continue
                
                custo_str = str(linha.get('Preco_Custo', linha.get('PrecoCusto', '0'))).replace(',', '.')
                venda_str = str(linha.get('Preco_Venda', linha.get('PrecoVenda', '0'))).replace(',', '.')
                estoque_str = str(linha.get('Estoque', '0')).replace(',', '.')

                novo_produto = Produto(
                    codigo_sku = linha.get('Codigo', linha.get('Codigo_SKU', '')),
                    nome = nome,
                    categoria = linha.get('Categoria', ''),
                    descricao = linha.get('Tipo_Venda', linha.get('TipoVenda', '')), 
                    preco_custo = float(custo_str) if custo_str else 0.0,
                    preco_venda = float(venda_str) if venda_str else 0.0,
                    estoque = float(estoque_str) if estoque_str else 0.0,
                    loja_id = loja_id
                )
                db.session.add(novo_produto)
                produtos_adicionados += 1
            
            db.session.commit()
            flash(f'✅ Sucesso! {produtos_adicionados} produtos foram importados para o estoque.', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'⚠️ Erro ao ler a planilha. Verifique se as colunas estão certas. Erro: {str(e)}', 'danger')
            
    else:
        flash('Por favor, envie apenas arquivos no formato .csv', 'warning')
        
    return redirect(url_for('home'))
# ---------------------------------------------------

@app.route('/editar_produto/<int:id>', methods=['GET', 'POST'])
def editar_produto(id):
    p = Produto.query.filter_by(id=id, loja_id=session['loja_id']).first_or_404()
    if request.method == 'POST':
        p.codigo_sku = request.form.get('sku')
        p.nome = request.form.get('nome')
        p.descricao = request.form.get('descricao')
        p.categoria = request.form.get('categoria')
        p.preco_custo = float(request.form.get('preco_custo').replace(',', '.'))
        p.preco_venda = float(request.form.get('preco').replace(',', '.'))
        p.estoque = float(request.form.get('quantidade').replace(',', '.'))
        db.session.commit()
        flash('✏️ Produto Atualizado!', 'success')
        return redirect(url_for('home'))
    return render_template('editar_produto.html', p=p)

@app.route('/desmembrar', methods=['POST'])
def desmembrar():
    p_origem = Produto.query.get(request.form.get('origem_id'))
    p_destino = Produto.query.get(request.form.get('destino_id'))
    q_origem = float(request.form.get('qtd_origem').replace(',', '.'))
    q_destino = float(request.form.get('qtd_destino').replace(',', '.'))
    
    if p_origem and p_destino and p_origem.estoque >= q_origem:
        p_origem.estoque -= q_origem
        p_destino.estoque += q_destino
        db.session.commit()
        flash('📦 Conversão (Granel) realizada com sucesso!', 'success')
    else:
        flash('⚠️ Erro: Estoque insuficiente na origem.', 'danger')
        
    return redirect(url_for('home'))

@app.route('/inativar_produto/<int:id>')
def inativar_produto(id):
    p = Produto.query.get_or_404(id)
    p.ativo = False
    db.session.commit()
    flash('🗑️ Produto movido para a lixeira!', 'warning')
    return redirect(url_for('home'))

@app.route('/inativos')
def inativos():
    if 'loja_id' not in session: return redirect(url_for('login'))
    prods_inativos = Produto.query.filter_by(loja_id=session['loja_id'], ativo=False).all()
    return render_template('inativos.html', produtos=prods_inativos)

@app.route('/ativar_produto/<int:id>')
def ativar_produto(id):
    p = Produto.query.get_or_404(id)
    p.ativo = True
    db.session.commit()
    flash('✅ Produto restaurado para o estoque!', 'success')
    return redirect(url_for('inativos'))

# ==========================================
# CLIENTES E PDV
# ==========================================
@app.route('/clientes', methods=['GET', 'POST'])
def clientes():
    if 'loja_id' not in session: return redirect(url_for('login'))
    if request.method == 'POST':
        c = Cliente(
            nome=request.form.get('nome'), telefone=request.form.get('telefone'),
            cpf=request.form.get('cpf'), nome_pet=request.form.get('nome_pet'),
            rua=request.form.get('rua'), numero=request.form.get('numero'),
            apartamento=request.form.get('apartamento'), bairro=request.form.get('bairro'),
            loja_id=session['loja_id']
        )
        db.session.add(c); db.session.commit()
        flash('✅ Cliente salvo!', 'success')
    return render_template('clientes.html', clientes=Cliente.query.filter_by(loja_id=session['loja_id']).all())

@app.route('/editar_cliente/<int:id>', methods=['GET', 'POST'])
def editar_cliente(id):
    if 'loja_id' not in session: return redirect(url_for('login'))
    c = Cliente.query.filter_by(id=id, loja_id=session['loja_id']).first_or_404()
    if request.method == 'POST':
        c.nome = request.form.get('nome')
        c.telefone = request.form.get('telefone')
        c.cpf = request.form.get('cpf')
        c.nome_pet = request.form.get('nome_pet')
        c.nome_pet_2 = request.form.get('nome_pet_2')
        c.nome_pet_3 = request.form.get('nome_pet_3')
        c.rua = request.form.get('rua')
        c.numero = request.form.get('numero')
        c.bairro = request.form.get('bairro')
        db.session.commit()
        flash('✏️ Cliente atualizado com sucesso!', 'success')
        return redirect(url_for('clientes'))
    return render_template('editar_cliente.html', cliente=c)

@app.route('/excluir_cliente/<int:id>')
def excluir_cliente(id):
    if 'loja_id' not in session: return redirect(url_for('login'))
    c = Cliente.query.filter_by(id=id, loja_id=session['loja_id']).first_or_404()
    db.session.delete(c)
    db.session.commit()
    flash('🗑️ Cliente excluído do sistema!', 'warning')
    return redirect(url_for('clientes'))

@app.route('/historico_cliente/<int:id>')
def historico_cliente(id):
    if 'loja_id' not in session: return jsonify([])
    vendas = Venda.query.filter_by(cliente_id=id, loja_id=session['loja_id']).order_by(Venda.data_venda.desc()).all()
    dados = []
    for v in vendas:
        dados.append({
            'data': v.data_venda.strftime('%d/%m/%Y %H:%M'),
            'produto': v.produto.nome,
            'qtd': v.quantidade,
            'valor': v.valor_pago_1 + (v.valor_pago_2 or 0)
        })
    return jsonify(dados)

@app.route('/pdv')
def pdv():
    if 'loja_id' not in session: return redirect(url_for('login'))
    carrinho = session.get('carrinho', [])
    total = sum(i['subtotal'] for i in carrinho)
    
    custo_total = 0
    for item in carrinho:
        p = Produto.query.get(item['produto_id'])
        if p:
            custo_total += (p.preco_custo or 0) * item['quantidade']
            
    prods = Produto.query.filter_by(loja_id=session['loja_id'], ativo=True).all()
    clis = Cliente.query.filter_by(loja_id=session['loja_id']).all()
    
    return render_template('pdv.html', produtos=prods, clientes=clis, carrinho=carrinho, 
                           total_carrinho=f"{total:.2f}".replace('.', ','), 
                           custo_total=custo_total)

@app.route('/add_carrinho', methods=['POST'])
def add_carrinho():
    p = Produto.query.get(request.form.get('produto_id'))
    qtd = float(request.form.get('quantidade').replace(',', '.'))
    desc = float(request.form.get('desconto') or 0)
    if p:
        item = {
            'produto_id': p.id, 'nome': p.nome, 'quantidade': qtd, 
            'desconto_perc': desc, 'subtotal': round((p.preco_venda * qtd) * (1 - desc/100), 2),
            'dias_duracao': int(request.form.get('dias_duracao') or 30)
        }
        session.setdefault('carrinho', []).append(item)
        session.modified = True
    return redirect(url_for('pdv'))

@app.route('/limpar_carrinho')
def limpar_carrinho():
    session.pop('carrinho', None)
    return redirect(url_for('pdv'))

@app.route('/finalizar_venda', methods=['POST'])
def finalizar_venda():
    carrinho = session.get('carrinho', [])
    desconto_final_perc = float(request.form.get('desconto_final') or 0)
    fator_desconto = 1 - (desconto_final_perc / 100)
    
    for item in carrinho:
        p = Produto.query.get(item['produto_id'])
        if p:
            p.estoque -= item['quantidade']
            valor_final_item = item['subtotal'] * fator_desconto
            
            nova_venda = Venda(
                produto_id=p.id, cliente_id=request.form.get('cliente_id') or None,
                loja_id=session['loja_id'], quantidade=item['quantidade'],
                forma_pagamento_1=request.form.get('forma_pagamento_1'),
                valor_pago_1=valor_final_item,
                data_previsao_fim=hora_brasilia() + timedelta(days=item['dias_duracao']),
                vendedor=session.get('vendedor')
            )
            db.session.add(nova_venda)
            
    db.session.commit()
    session.pop('carrinho', None)
    flash('🛒 Venda Concluída com Sucesso!', 'success')
    return redirect(url_for('pdv'))

@app.route('/registrar_perda', methods=['POST'])
def registrar_perda():
    if 'loja_id' not in session: return redirect(url_for('login'))
    nome_prod = request.form.get('nome_produto_perdido')
    if nome_prod:
        perda = VendaPerdida(nome_produto=nome_prod, loja_id=session['loja_id'])
        db.session.add(perda)
        db.session.commit()
        flash('📉 Perda registrada para o Radar!', 'warning')
    return redirect(url_for('pdv'))

# ==========================================
# REPRESENTANTES, RADAR E FINANCEIRO
# ==========================================
@app.route('/representantes', methods=['GET', 'POST'])
def representantes():
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': return redirect(url_for('pdv'))
    if request.method == 'POST':
        novo = Representante(
            nome_fantasia=request.form.get('nome_fantasia'), cnpj=request.form.get('cnpj'),
            representante_nome=request.form.get('representante_nome'), whatsapp=request.form.get('whatsapp'),
            prazo_entrega=request.form.get('prazo_entrega'), pedido_minimo=request.form.get('pedido_minimo'),
            observacoes=request.form.get('observacoes'), loja_id=session['loja_id']
        )
        db.session.add(novo); db.session.commit(); flash('✅ Salvo!', 'success')
    return render_template('representantes.html', representantes=Representante.query.filter_by(loja_id=session['loja_id']).all())

@app.route('/editar_representante/<int:id>', methods=['POST'])
def editar_representante(id):
    f = Representante.query.get_or_404(id)
    f.nome_fantasia = request.form.get('nome_fantasia')
    f.cnpj = request.form.get('cnpj')
    f.representante_nome = request.form.get('representante_nome')
    f.whatsapp = request.form.get('whatsapp')
    f.prazo_entrega = request.form.get('prazo_entrega')
    f.pedido_minimo = request.form.get('pedido_minimo')
    db.session.commit(); flash('✅ Fornecedor atualizado!', 'success')
    return redirect(url_for('representantes'))

@app.route('/excluir_representante/<int:id>')
def excluir_representante(id):
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': return redirect(url_for('pdv'))
    f = Representante.query.get_or_404(id)
    if f.loja_id == session['loja_id']:
        db.session.delete(f)
        db.session.commit()
        flash('🗑️ Fornecedor removido!', 'warning')
    return redirect(url_for('representantes'))

@app.route('/radar')
def radar():
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': return redirect(url_for('pdv'))
    alertas = Venda.query.filter_by(loja_id=session['loja_id']).filter(Venda.data_previsao_fim <= hora_brasilia() + timedelta(days=7)).all()
    ranking = Counter([p.nome_produto for p in VendaPerdida.query.filter_by(loja_id=session['loja_id']).all()]).most_common(10)
    estoque_critico = Produto.query.filter_by(loja_id=session['loja_id'], ativo=True).filter(Produto.estoque <= 5).all()
    return render_template('radar.html', alertas=alertas, ranking=ranking, estoque_critico=estoque_critico)

# --- NOVO: FILTRO DE DATAS NOS RELATÓRIOS ---
@app.route('/relatorios')
def relatorios():
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': return redirect(url_for('pdv'))
    
    data_inicio_str = request.values.get('data_inicio')
    data_fim_str = request.values.get('data_fim')
    
    query = Venda.query.filter_by(loja_id=session['loja_id'])
    
    if data_inicio_str:
        data_inicio = datetime.strptime(data_inicio_str, '%Y-%m-%d')
        query = query.filter(Venda.data_venda >= data_inicio)
        
    if data_fim_str:
        data_fim = datetime.strptime(data_fim_str, '%Y-%m-%d') + timedelta(hours=23, minutes=59, seconds=59)
        query = query.filter(Venda.data_venda <= data_fim)
        
    vendas = query.order_by(Venda.data_venda.desc()).all()
    
    total_bruto = sum(v.valor_pago_1 + (v.valor_pago_2 or 0) for v in vendas)
    lucro_total = 0
    pix = sum(v.valor_pago_1 for v in vendas if v.forma_pagamento_1 == 'Pix')
    credito = sum(v.valor_pago_1 for v in vendas if v.forma_pagamento_1 == 'Cartão de Crédito')
    debito = sum(v.valor_pago_1 for v in vendas if v.forma_pagamento_1 == 'Cartão de Débito')
    dinheiro = sum(v.valor_pago_1 for v in vendas if v.forma_pagamento_1 == 'Dinheiro')

    for v in vendas:
        custo = (v.produto.preco_custo or 0) * v.quantidade
        lucro_total += ((v.valor_pago_1 + (v.valor_pago_2 or 0)) - custo)

    return render_template('relatorios.html', 
        vendas=vendas, 
        total=f"{total_bruto:.2f}".replace('.', ','),
        lucro_total_formatado=f"{lucro_total:.2f}".replace('.', ','),
        pix=f"{pix:.2f}".replace('.', ','), pix_raw=pix,
        credito=f"{credito:.2f}".replace('.', ','), credito_raw=credito,
        debito=f"{debito:.2f}".replace('.', ','), debito_raw=debito,
        dinheiro=f"{dinheiro:.2f}".replace('.', ','), dinheiro_raw=dinheiro,
        data_inicio=data_inicio_str,
        data_fim=data_fim_str
    )
# --------------------------------------------

# ==========================================
# FUNCIONÁRIOS / CAIXAS
# ==========================================
@app.route('/funcionarios', methods=['GET', 'POST'])
def funcionarios():
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': 
        return redirect(url_for('pdv'))
        
    if request.method == 'POST':
        nome = request.form.get('nome')
        usuario = request.form.get('usuario').strip().lower()
        senha = request.form.get('senha')
        cargo = request.form.get('cargo')
        
        if Funcionario.query.filter_by(usuario=usuario).first() or Loja.query.filter_by(usuario=usuario).first():
            flash('⚠️ Erro: Este usuário de login já está em uso!', 'danger')
        else:
            novo_func = Funcionario(
                nome=nome, usuario=usuario, 
                senha=generate_password_hash(senha), 
                cargo=cargo, loja_id=session['loja_id']
            )
            db.session.add(novo_func)
            db.session.commit()
            flash('✅ Funcionário cadastrado com sucesso!', 'success')
            
    funcs = Funcionario.query.filter_by(loja_id=session['loja_id']).all()
    return render_template('funcionarios.html', funcionarios=funcs)

@app.route('/excluir_funcionario/<int:id>')
def excluir_funcionario(id):
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': 
        return redirect(url_for('pdv'))
    f = Funcionario.query.get_or_404(id)
    if f.loja_id == session['loja_id']:
        db.session.delete(f)
        db.session.commit()
        flash('🗑️ Funcionário removido do sistema.', 'warning')
    return redirect(url_for('funcionarios'))

@app.route('/resetar_senha/<int:id>')
def resetar_senha_funcionario(id):
    if 'loja_id' not in session or session.get('cargo') != 'Gerente': 
        return redirect(url_for('pdv'))
    
    f = Funcionario.query.get_or_404(id)
    if f.loja_id == session['loja_id']:
        f.senha = generate_password_hash('123456')
        f.primeiro_acesso = True
        db.session.commit()
        flash(f'🔄 Senha de {f.nome} resetada para 123456!', 'success')
        
    return redirect(url_for('funcionarios'))

# ==========================================
# INICIALIZAÇÃO
# ==========================================
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)